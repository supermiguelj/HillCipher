This is a hill cipher encryption algorithm that takes in two files: the text you wish to encrypt, and the key. The hill cipher method uses linear algebra to encrypt the plaintext and outputs the encrypted text into the console.

To run the program, in the terminal, input the name of the executable, then the text file containing the plaintext, and lastly, the text file containing the key.
